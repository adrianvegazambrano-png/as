import React, { useState, useRef, useCallback } from 'react';
import { Download, FileText, Settings, Eye } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

import { InvoiceData } from './types';
import { generateId } from './utils';
import InvoiceForm from './components/InvoiceForm';
import InvoicePreview from './components/InvoicePreview';

const initialInvoiceData: InvoiceData = {
  id: `FAC-${generateId()}`,
  date: new Date().toISOString().split('T')[0],
  dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // +30 days
  currency: 'MXN',
  taxRate: 16,
  sender: {
    name: '',
    taxId: '',
    address: '',
    email: '',
  },
  receiver: {
    name: '',
    taxId: '',
    address: '',
    email: '',
  },
  items: [
    { id: generateId(), description: 'Servicios profesionales', quantity: 1, unitPrice: 1500 }
  ],
  notes: 'Pago mediante transferencia bancaria.\nGracias por su preferencia.',
};

const App: React.FC = () => {
  const [invoiceData, setInvoiceData] = useState<InvoiceData>(initialInvoiceData);
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  
  const previewRef = useRef<HTMLDivElement>(null);

  const handleDataChange = useCallback((newData: InvoiceData) => {
    setInvoiceData(newData);
  }, []);

  const generatePDF = async () => {
    if (!previewRef.current) return;
    
    setIsGeneratingPDF(true);
    try {
      // Temporarily ensure the preview is visible for html2canvas if it's hidden on mobile
      const originalDisplay = previewRef.current.style.display;
      previewRef.current.style.display = 'block';

      const canvas = await html2canvas(previewRef.current, {
        scale: 2, // Higher scale for better resolution
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff'
      });

      previewRef.current.style.display = originalDisplay;

      const imgData = canvas.toDataURL('image/png');
      
      // A4 dimensions in mm
      const pdfWidth = 210;
      const pdfHeight = 297;
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      // Calculate image dimensions to fit A4 while maintaining aspect ratio
      const imgProps = pdf.getImageProperties(imgData);
      const imgRatio = imgProps.width / imgProps.height;
      const pdfRatio = pdfWidth / pdfHeight;

      let finalWidth = pdfWidth;
      let finalHeight = pdfHeight;

      if (imgRatio > pdfRatio) {
        // Image is wider than A4
        finalHeight = pdfWidth / imgRatio;
      } else {
        // Image is taller than A4
        finalWidth = pdfHeight * imgRatio;
      }

      // Center the image if it doesn't perfectly fit
      const xOffset = (pdfWidth - finalWidth) / 2;
      const yOffset = (pdfHeight - finalHeight) / 2;

      pdf.addImage(imgData, 'PNG', xOffset, yOffset, finalWidth, finalHeight);
      pdf.save(`Factura_${invoiceData.id || 'Borrador'}.pdf`);
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Hubo un error al generar el PDF. Por favor, intente de nuevo.');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Navigation */}
      <header className="bg-slate-900 text-white sticky top-0 z-10 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-blue-500 p-1.5 rounded-lg">
              <FileText size={24} className="text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">FacturaPro</h1>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Mobile Tab Switcher */}
            <div className="flex lg:hidden bg-slate-800 rounded-lg p-1">
              <button
                onClick={() => setActiveTab('edit')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1 transition-colors ${
                  activeTab === 'edit' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Settings size={16} /> Editar
              </button>
              <button
                onClick={() => setActiveTab('preview')}
                className={`px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1 transition-colors ${
                  activeTab === 'preview' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Eye size={16} /> Vista Previa
              </button>
            </div>

            <button
              onClick={generatePDF}
              disabled={isGeneratingPDF}
              className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
            >
              {isGeneratingPDF ? (
                <span className="animate-pulse">Generando...</span>
              ) : (
                <>
                  <Download size={18} />
                  <span className="hidden sm:inline">Descargar PDF</span>
                  <span className="sm:hidden">PDF</span>
                </>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-grow max-w-7xl mx-auto w-full p-4 sm:p-6 lg:p-8 flex flex-col lg:flex-row gap-8">
        
        {/* Left Column: Form (Hidden on mobile if preview tab is active) */}
        <div className={`w-full lg:w-1/2 xl:w-5/12 flex-shrink-0 ${activeTab === 'preview' ? 'hidden lg:block' : 'block'}`}>
          <div className="sticky top-24">
            <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-2">
              <Settings className="text-slate-400" />
              Datos de la Factura
            </h2>
            <InvoiceForm data={invoiceData} onChange={handleDataChange} />
          </div>
        </div>

        {/* Right Column: Preview (Hidden on mobile if edit tab is active) */}
        <div className={`w-full lg:w-1/2 xl:w-7/12 flex-grow ${activeTab === 'edit' ? 'hidden lg:block' : 'block'}`}>
          <div className="sticky top-24">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                <Eye className="text-slate-400" />
                Vista Previa
              </h2>
              <span className="text-sm text-slate-500 bg-slate-200 px-2 py-1 rounded-md">Formato A4</span>
            </div>
            
            {/* Preview Container with scrolling if it overflows */}
            <div className="bg-slate-200 p-4 sm:p-8 rounded-xl overflow-x-auto shadow-inner flex justify-center items-start min-h-[800px]">
              {/* Scale down slightly on smaller screens to fit, but keep actual dimensions for PDF */}
              <div className="transform origin-top scale-[0.6] sm:scale-[0.8] xl:scale-100 transition-transform">
                <InvoicePreview ref={previewRef} data={invoiceData} />
              </div>
            </div>
          </div>
        </div>

      </main>
    </div>
  );
};

export default App;
