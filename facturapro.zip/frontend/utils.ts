import { InvoiceData, InvoiceItem, InvoiceTotals } from './types';

export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 9).toUpperCase();
};

export const formatCurrency = (amount: number, currency: string = 'MXN'): string => {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: currency,
  }).format(amount);
};

export const formatDate = (dateString: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString);
  // Adjust for timezone issues if needed, but simple format is usually fine for input dates
  return new Intl.DateTimeFormat('es-MX', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(date);
};

export const calculateTotals = (items: InvoiceItem[], taxRate: number): InvoiceTotals => {
  const subtotal = items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
  const taxAmount = subtotal * (taxRate / 100);
  const total = subtotal + taxAmount;

  return { subtotal, taxAmount, total };
};

export const generateQRDataString = (data: InvoiceData, totals: InvoiceTotals): string => {
  // A standard format for tax QR codes often includes IDs, totals, and tax IDs.
  return `Factura:${data.id}|Emisor:${data.sender.taxId}|Receptor:${data.receiver.taxId}|Total:${totals.total.toFixed(2)}|Fecha:${data.date}`;
};
