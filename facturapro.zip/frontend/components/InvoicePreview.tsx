import React, { forwardRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { InvoiceData, InvoiceTotals } from '../types';
import { formatCurrency, formatDate, calculateTotals, generateQRDataString } from '../utils';

interface InvoicePreviewProps {
  data: InvoiceData;
}

// Use forwardRef so the parent can capture this component's DOM node for PDF generation
const InvoicePreview = forwardRef<HTMLDivElement, InvoicePreviewProps>(({ data }, ref) => {
  const totals: InvoiceTotals = calculateTotals(data.items, data.taxRate);
  const qrData = generateQRDataString(data, totals);

  return (
    <div 
      ref={ref} 
      className="bg-white p-10 shadow-lg rounded-sm border border-slate-200 mx-auto"
      style={{ 
        width: '210mm', // A4 width
        minHeight: '297mm', // A4 height
        boxSizing: 'border-box',
        backgroundColor: '#ffffff' // Ensure white background for PDF
      }}
    >
      {/* Header */}
      <div className="flex justify-between items-start border-b-2 border-slate-800 pb-6 mb-8">
        <div>
          <h1 className="text-4xl font-bold text-slate-800 tracking-tight uppercase">Factura</h1>
          <p className="text-slate-500 mt-1 font-medium">Comprobante Fiscal Digital</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-slate-800 mb-2">Nº {data.id || '---'}</div>
          <div className="text-sm text-slate-600 grid grid-cols-2 gap-x-4 gap-y-1 text-right">
            <span className="font-semibold">Fecha de Emisión:</span>
            <span>{formatDate(data.date) || '---'}</span>
            <span className="font-semibold">Fecha de Vencimiento:</span>
            <span>{formatDate(data.dueDate) || '---'}</span>
          </div>
        </div>
      </div>

      {/* Entities */}
      <div className="grid grid-cols-2 gap-12 mb-10">
        {/* Emisor */}
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Emisor</h3>
          <div className="text-slate-800 font-bold text-lg">{data.sender.name || 'Nombre del Emisor'}</div>
          <div className="text-sm text-slate-600 mt-1">
            <span className="font-semibold">RFC:</span> {data.sender.taxId || '---'}
          </div>
          <div className="text-sm text-slate-600 mt-1 whitespace-pre-line">
            {data.sender.address || 'Dirección del Emisor'}
          </div>
        </div>

        {/* Receptor */}
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Receptor</h3>
          <div className="text-slate-800 font-bold text-lg">{data.receiver.name || 'Nombre del Receptor'}</div>
          <div className="text-sm text-slate-600 mt-1">
            <span className="font-semibold">RFC:</span> {data.receiver.taxId || '---'}
          </div>
          <div className="text-sm text-slate-600 mt-1 whitespace-pre-line">
            {data.receiver.address || 'Dirección del Receptor'}
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="mb-10">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b-2 border-slate-800 text-slate-800">
              <th className="py-3 px-2 font-bold text-sm uppercase tracking-wider w-1/2">Descripción</th>
              <th className="py-3 px-2 font-bold text-sm uppercase tracking-wider text-center">Cant.</th>
              <th className="py-3 px-2 font-bold text-sm uppercase tracking-wider text-right">Precio Unit.</th>
              <th className="py-3 px-2 font-bold text-sm uppercase tracking-wider text-right">Importe</th>
            </tr>
          </thead>
          <tbody className="text-slate-700 text-sm">
            {data.items.length > 0 ? (
              data.items.map((item, index) => (
                <tr key={item.id} className={index % 2 === 0 ? 'bg-slate-50' : 'bg-white'}>
                  <td className="py-3 px-2 border-b border-slate-100">{item.description || '---'}</td>
                  <td className="py-3 px-2 border-b border-slate-100 text-center">{item.quantity}</td>
                  <td className="py-3 px-2 border-b border-slate-100 text-right">{formatCurrency(item.unitPrice, data.currency)}</td>
                  <td className="py-3 px-2 border-b border-slate-100 text-right font-medium">
                    {formatCurrency(item.quantity * item.unitPrice, data.currency)}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={4} className="py-8 text-center text-slate-400 italic border-b border-slate-100">
                  No hay conceptos en esta factura.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Totals & QR Section */}
      <div className="flex justify-between items-end mt-auto">
        {/* QR Code & Notes */}
        <div className="w-1/2 pr-8">
          <div className="mb-6">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Notas / Condiciones</h4>
            <p className="text-sm text-slate-600 whitespace-pre-line min-h-[3rem]">
              {data.notes || 'Sin notas adicionales.'}
            </p>
          </div>
          
          <div className="flex items-start gap-4">
            <div className="p-2 bg-white border border-slate-200 rounded-lg inline-block">
              <QRCodeSVG 
                value={qrData} 
                size={100} 
                level="M"
                includeMargin={false}
              />
            </div>
            <div className="text-xs text-slate-500 max-w-[200px]">
              <p className="font-semibold mb-1">Sello Digital / Verificación</p>
              <p>Escanee este código QR para verificar la validez de este comprobante fiscal.</p>
            </div>
          </div>
        </div>

        {/* Totals */}
        <div className="w-1/3">
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
            <div className="flex justify-between py-2 text-sm text-slate-600">
              <span>Subtotal:</span>
              <span className="font-medium">{formatCurrency(totals.subtotal, data.currency)}</span>
            </div>
            <div className="flex justify-between py-2 text-sm text-slate-600 border-b border-slate-200">
              <span>IVA ({data.taxRate}%):</span>
              <span className="font-medium">{formatCurrency(totals.taxAmount, data.currency)}</span>
            </div>
            <div className="flex justify-between py-3 text-lg font-bold text-slate-800">
              <span>Total:</span>
              <span>{formatCurrency(totals.total, data.currency)}</span>
            </div>
            <div className="text-right text-xs text-slate-500 mt-1">
              Moneda: {data.currency}
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <div className="mt-12 pt-4 border-t border-slate-200 text-center text-xs text-slate-400">
        Este documento es una representación impresa de un CFDI. Generado por FacturaPro.
      </div>
    </div>
  );
});

InvoicePreview.displayName = 'InvoicePreview';

export default InvoicePreview;
