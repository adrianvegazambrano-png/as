import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { InvoiceData, InvoiceItem } from '../types';
import { generateId } from '../utils';

interface InvoiceFormProps {
  data: InvoiceData;
  onChange: (data: InvoiceData) => void;
}

const InvoiceForm: React.FC<InvoiceFormProps> = ({ data, onChange }) => {
  const handleNestedChange = (
    section: 'sender' | 'receiver',
    field: keyof InvoiceData['sender'],
    value: string
  ) => {
    onChange({
      ...data,
      [section]: {
        ...data[section],
        [field]: value,
      },
    });
  };

  const handleBasicChange = (field: keyof InvoiceData, value: string | number) => {
    onChange({ ...data, [field]: value });
  };

  const addItem = () => {
    const newItem: InvoiceItem = {
      id: generateId(),
      description: '',
      quantity: 1,
      unitPrice: 0,
    };
    onChange({ ...data, items: [...data.items, newItem] });
  };

  const removeItem = (id: string) => {
    onChange({ ...data, items: data.items.filter((item) => item.id !== id) });
  };

  const updateItem = (id: string, field: keyof InvoiceItem, value: string | number) => {
    onChange({
      ...data,
      items: data.items.map((item) =>
        item.id === id ? { ...item, [field]: value } : item
      ),
    });
  };

  return (
    <div className="space-y-8 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
      
      {/* Header Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Nº Factura</label>
          <input
            type="text"
            value={data.id}
            onChange={(e) => handleBasicChange('id', e.target.value)}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Fecha</label>
          <input
            type="date"
            value={data.date}
            onChange={(e) => handleBasicChange('date', e.target.value)}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Vencimiento</label>
          <input
            type="date"
            value={data.dueDate}
            onChange={(e) => handleBasicChange('dueDate', e.target.value)}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Sender */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">Datos del Emisor</h3>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Nombre / Razón Social</label>
            <input
              type="text"
              value={data.sender.name}
              onChange={(e) => handleNestedChange('sender', 'name', e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Tu Empresa S.A. de C.V."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">RFC / Identificación Fiscal</label>
            <input
              type="text"
              value={data.sender.taxId}
              onChange={(e) => handleNestedChange('sender', 'taxId', e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none uppercase"
              placeholder="XAXX010101000"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Dirección</label>
            <input
              type="text"
              value={data.sender.address}
              onChange={(e) => handleNestedChange('sender', 'address', e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Calle Principal 123, Ciudad"
            />
          </div>
        </div>

        {/* Receiver */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-800 border-b pb-2">Datos del Receptor (Cliente)</h3>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Nombre / Razón Social</label>
            <input
              type="text"
              value={data.receiver.name}
              onChange={(e) => handleNestedChange('receiver', 'name', e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Cliente S.A. de C.V."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">RFC / Identificación Fiscal</label>
            <input
              type="text"
              value={data.receiver.taxId}
              onChange={(e) => handleNestedChange('receiver', 'taxId', e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none uppercase"
              placeholder="XAXX010101000"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Dirección</label>
            <input
              type="text"
              value={data.receiver.address}
              onChange={(e) => handleNestedChange('receiver', 'address', e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Avenida Secundaria 456, Ciudad"
            />
          </div>
        </div>
      </div>

      {/* Items */}
      <div>
        <div className="flex justify-between items-center mb-4 border-b pb-2">
          <h3 className="text-lg font-semibold text-slate-800">Conceptos</h3>
          <button
            onClick={addItem}
            className="flex items-center gap-1 text-sm bg-blue-50 text-blue-600 px-3 py-1.5 rounded-md hover:bg-blue-100 transition-colors font-medium"
          >
            <Plus size={16} /> Agregar Concepto
          </button>
        </div>
        
        <div className="space-y-3">
          {/* Header row for items */}
          <div className="hidden md:grid grid-cols-12 gap-2 text-sm font-medium text-slate-500 px-2">
            <div className="col-span-6">Descripción</div>
            <div className="col-span-2 text-center">Cant.</div>
            <div className="col-span-3 text-right">Precio Unit.</div>
            <div className="col-span-1"></div>
          </div>

          {data.items.map((item) => (
            <div key={item.id} className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center bg-slate-50 p-3 md:p-2 rounded-lg border border-slate-100">
              <div className="col-span-1 md:col-span-6">
                <label className="md:hidden text-xs text-slate-500 mb-1 block">Descripción</label>
                <input
                  type="text"
                  value={item.description}
                  onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                  placeholder="Descripción del servicio o producto"
                />
              </div>
              <div className="col-span-1 md:col-span-2">
                <label className="md:hidden text-xs text-slate-500 mb-1 block">Cantidad</label>
                <input
                  type="number"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => updateItem(item.id, 'quantity', parseFloat(e.target.value) || 0)}
                  className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none text-sm text-center"
                />
              </div>
              <div className="col-span-1 md:col-span-3">
                <label className="md:hidden text-xs text-slate-500 mb-1 block">Precio Unitario</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 text-sm">$</span>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={item.unitPrice}
                    onChange={(e) => updateItem(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                    className="w-full p-2 pl-7 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none text-sm text-right"
                  />
                </div>
              </div>
              <div className="col-span-1 flex justify-end md:justify-center mt-2 md:mt-0">
                <button
                  onClick={() => removeItem(item.id)}
                  className="text-red-400 hover:text-red-600 p-2 rounded-md hover:bg-red-50 transition-colors"
                  title="Eliminar concepto"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))}
          {data.items.length === 0 && (
            <div className="text-center py-8 text-slate-400 text-sm border-2 border-dashed border-slate-200 rounded-lg">
              No hay conceptos agregados.
            </div>
          )}
        </div>
      </div>

      {/* Footer Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Notas / Condiciones</label>
          <textarea
            value={data.notes}
            onChange={(e) => handleBasicChange('notes', e.target.value)}
            className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none h-24 resize-none"
            placeholder="Gracias por su preferencia. Pago a 30 días..."
          />
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-slate-700">Moneda</label>
            <select
              value={data.currency}
              onChange={(e) => handleBasicChange('currency', e.target.value)}
              className="p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none bg-white"
            >
              <option value="MXN">MXN - Peso Mexicano</option>
              <option value="USD">USD - Dólar Estadounidense</option>
              <option value="EUR">EUR - Euro</option>
            </select>
          </div>
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium text-slate-700">Tasa de Impuesto (IVA %)</label>
            <div className="relative w-32">
              <input
                type="number"
                min="0"
                max="100"
                value={data.taxRate}
                onChange={(e) => handleBasicChange('taxRate', parseFloat(e.target.value) || 0)}
                className="w-full p-2 pr-8 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none text-right"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">%</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default InvoiceForm;
