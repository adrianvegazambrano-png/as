export interface CompanyDetails {
  name: string;
  taxId: string; // RFC, NIF, CUIT, etc.
  address: string;
  email: string;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
}

export interface InvoiceData {
  id: string;
  date: string;
  dueDate: string;
  currency: string;
  taxRate: number; // Percentage (e.g., 16 for 16%)
  sender: CompanyDetails;
  receiver: CompanyDetails;
  items: InvoiceItem[];
  notes: string;
}

export interface InvoiceTotals {
  subtotal: number;
  taxAmount: number;
  total: number;
}
